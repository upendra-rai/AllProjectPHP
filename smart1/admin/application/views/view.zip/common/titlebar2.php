<div class="container-fluid" id="top_titile">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro" style="float:left;">
                        <img src="<?php echo base_url('catalogs'); ?>/img/logo.png" alt="" width="50" />
                    </div>
                    <div class="logo-pro" style="float:right;">
                        <button  type="button" id="my_nav" class="btn" style="background:transparent; border:none; "><i class="ion-android-apps" style="font-size:26px;"></i></button>
                    </div>
                </div>
            </div>
</div>
<div class="header-advance-area" style="height: 38px;">
            <div class="header-top-area" >
                <div class="container-fluid">
                    <div class="row" style="height: 40px;">
                       
                           
                      
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
           <!-- <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                    
                        <li class="active">
                            <a href="<?php echo base_url() ?>dashboard">
								   <span class="educate-icon educate-home icon-wrap"></span>
								   <span class="mini-click-non">Dashboard</span>
								</a>
                           
                        </li>
                        
                        <li>
                            <a class="has-arrow" href="all-professors.html" aria-expanded="false"><span class="educate-icon educate-professor icon-wrap"></span> <span class="mini-click-non">Customers</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="<?php echo base_url(); ?>customer/add_customer"><span class="mini-sub-pro">Add Customers</span></a></li>
                                <li><a title="Add Professor" href="<?php echo base_url(); ?>customer/list_customer"><span class="mini-sub-pro">Update Customers</span></a></li>
                           
                                
                            </ul>
                        </li>
                       
						
						<li>
                            <a href="<?php echo base_url(); ?>team" aria-expanded="false"><span class="educate-icon educate-course icon-wrap"></span> <span class="mini-click-non">Manage Team</span></a>
                            
                        </li>
                        <li>
                            <a class="has-arrow"  href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Report</span></a>
                           <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="<?php echo base_url(); ?>report/customer_report"><span class="mini-sub-pro">Customer Report</span></a></li>
                                <li><a title="Add Professor" href="<?php echo base_url(); ?>report/transaction_report"><span class="mini-sub-pro">Transaction Report</span></a></li>
                                <li><a title="Add Professor" href="<?php echo base_url(); ?>report/recharge_report"><span class="mini-sub-pro">Recharge Report</span></a></li>
                                <li><a title="Add Professor" href="<?php echo base_url(); ?>report/agent_report"><span class="mini-sub-pro">Agent Report</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>dashboard/profile" aria-expanded="false"><span class="educate-icon educate-department icon-wrap"></span> <span class="mini-click-non">Change Password</span></a>
                            
                        </li>
                       
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
            <!-- Mobile Menu end -->
    
          <nav class="mobo_menu">
                    <ul class="mobo_menu_box" class="nav navbar-nav menu">
					    <li><a href="<?php echo base_url() ?>dashboard">Home</a></li>
                        <li><a href="<?php echo base_url(); ?>customer/add_customer">Add Customer</a></li>
						<li><a href="<?php echo base_url(); ?>team">Team Management</a></li>
                        <li><a href="<?php echo base_url(); ?>product">Team Management</a></li>
                        <li><a href="<?php echo base_url(); ?>report/customer_report">Customer Report</a></li>
                        <li><a href="<?php echo base_url(); ?>report/transaction_report">Transaction Report</a></li>
                        <li><a href="<?php echo base_url(); ?>report/recharge_report">Recharge Report</a></li>
                        <li><a href="<?php echo base_url(); ?>report/agent_report">Agent Report</a></li>
                        <li><a href="<?php echo base_url(); ?>dashboard/backup">Backup</a></li>
                        <li><a href="<?php echo base_url(); ?>dashboard/profile">Change Password</a></li>
                        
                       
                      
                    </ul>
            </nav>
</div>	