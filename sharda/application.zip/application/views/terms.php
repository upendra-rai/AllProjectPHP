<html>
<head>
<title> Terms_conditions</title>
     <?php include('header_link.php');?>
    </head>
<body>
   <?php $active='terms';
    ?>       <!--head_bar section -->
          <!--head_bar section -->
          <!--head_bar section -->
          <!--head_bar section -->
  <?php include('menu_bar.php'); ?>
         <!--main_img section -->
          <!--main_img section -->
          <!--main_img section -->
          <!--main_img section -->
    
    
    
          <!--content section -->
          <!--content section -->
          <!--content section -->
          <!--content section -->
    
    <section class="content" style="height:auto;">
        
            <div class="heading">
            <h3><b>TERMS & CONDITIONS</b></h3>
        </div>
        <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>WEBSITE- MERELY A VENUE/PLATFORM</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>USER(S) ELIGIBILITY</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>USER(S) AGREEMENT</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>AMENDMENT TO USER(S) AGREEMENT</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>INTELLECTUAL PROPERTY RIGHTS</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>COPYRIGHT</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>URL'S/SUB-DOMAIN</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>LINKS TO THIRD PARTY SITES</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>TERMINATION</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>REGISTERED USER(S)</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or ot
                    <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
                <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
                <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
                <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
                <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
                <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
                herwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
        <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
    <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
    <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
    <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
    <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
                
        </div>
    <div class="heading_under">
            <h4><b>DEAR CUSTOMER,</b></h4>
        </div>
            <div class="paragraph">
                <p>The following demonstrates terms and conditions of use (here-in-after referred to as an "Agreement"), applicable to your use of NumbersATM (hereinafter referred to as "web site"), w !important which promotes business between suppliers and buyers globally. It is an agreement between you as the user(s) of the web site (the "User(s)") and NumbersATM. (hereinafter referred to as "NumbersATM"). Before you subscribe to and/or begin participating in or using web site, NumbersATM believes that user(s) have fully read, understood and accept the agreement. If you do not agree to or wish to be bound by agreement , you may not access or otherwise use the web site or and NumbersATM wil not be responsible for any business activity.</p>
               
        </div>
    </section>
          <!--footer section -->
          <!--footer section -->
          <!--footer section -->
          <!--footer section -->
    
     <?php include('footer.php');?>
     <?php include('footer_script.php');?>
</body>
</html>