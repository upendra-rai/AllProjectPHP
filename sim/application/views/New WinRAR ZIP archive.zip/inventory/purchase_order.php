<!doctype html>
<html class="fixed">
<head>
		<?php $this->load->view('common/header_link'); ?>
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/modal.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/Lobibox.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/notifications.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/vendor/custom-scrollbar/jquery.mCustomScrollbar.css">
    
    <style type="text/css">
        .select2-container .select2-choices .select2-search-field input, .select2-container .select2-choice, .select2-container .select2-choices {
            
            border-color:#9f9f9f;
        }
        
        
        .my_drop_down{
            width: 100%;
            position: absolute;
            z-index: 99999;
            background-color: #202233;
            margin-top: -1px;
            display: none;
        }
        .my_drop_down li{
            width: 100%;
            border-left: 1px solid #424351;
            border-right: 1px solid #424351;
            
            padding: 8px 10px;
        
        }
        .my_drop_down li:hover{
            background-color: #006a9f;
            color:#ffffff;
        }
        .my_drop_down li.active{
            background-color: #006a9f;
            color:#ffffff;
        }
        
          .search_input_i{
            width:30px;
            height: 35px;
            position: absolute;
            color: #0088cc;
            padding: 5px 9px;
        }
        
        .form-group .form-control{
            box-shadow: none;
        }
        .form-group .form-control:focus{
           border-color: #005279;
            box-shadow: 0px 0px 10px 0px rgba(31,33,48,0.6);
        }
    </style>
</head>
<body>
		<section class="body">
			<!-- success message -->
			<div class="success_message">Kot Genrated Successfully</div>
			<!-- success message -->
      <?php $this->load->view("common/titlebar"); ?>

			<div class="inner-wrapper">
			  <?php $this->load->view('common/sidemenu'); ?>

				<section role="main" class="content-body" >
                    
                        <div class="col-md-12" style="padding:0px; padding-right:15px;">
					<section class="section_card">
						  <div class="panel-head" style="width:100%; height:30px; background-color:transparent; color:#dbd6d6; padding:10px 16px; ">
						      <h4 style="padding:0px; margin:0px; font-size:16px; text-transform:uppercase;">
										<i class="ion-android-radio-button-on" style="margin-right:10px;"></i>
											<?php if(isset($product_selected[0])){ echo 'Edit Product'; }else{ echo 'Add Product'; } ?>
									</h4>
						 </div>
						 <div class="panel-body" style="padding-left:0px; padding-right:0px;  background-color:#27293d; padding-top:15px; padding-bottom:0px;">
										<form class="form-horizontal form-bordered" action="<?php echo base_url(); ?>/inventory/purchase_order/" method="POST">
                                        <div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												<div class="col-md-12">
													  <select class="form-control" name="outlet">
                                                     <option>Select Outlet</option>
                                                     <?php foreach($outlet_list as $row){ ?>
                                                       <option value="<?php echo $row->outlet_id ?>" <?php if(isset($purchase_product_list[0]->outlet_id)){ if($purchase_product_list[0]->outlet_id == $row->outlet_id){ echo 'selected'; }  } ?> ><?php echo $row->outlet_name;  ?></option>
                                                     <?php } ?>
                                                 </select>
												</div>
											</div>
						               </div>
									   <div class="col-md-3"  >
										 <div class="form-group">
											 <div class="col-md-12">
												 <select class="form-control" name="supplier">
                                                     <option>Select Supplier</option>
                                                     <?php foreach($supplier_list as $row){ ?>
                                                       <option value="<?php echo $row->supplier_id ?>" <?php if(isset($purchase_product_list[0]->supplier_id)){ if($purchase_product_list[0]->supplier_id == $row->supplier_id){ echo 'selected'; }  } ?> ><?php echo $row->supplier_name;  ?></option>
                                                     <?php } ?>
                                                 </select>
											 </div>
										 </div>
									  </div>
									
                                      <div class="col-md-3">
										<div class="form-group">
											<div class="col-md-12">
												<input type="text" class="form-control" name="attachment" value="" placeholder="Attach File*" >
											</div>
										</div>
								      </div>  
                                            
                                      <div class="col-md-3">
										<div class="form-group">
											<div class="col-md-12">
												<input type="text" class="form-control" name="order_tax" value="" placeholder="Order Tax File*" >
											</div>
										</div>
								      </div>  
                                     
                                      <div class="col-md-3">
										<div class="form-group">
											<div class="col-md-12">
												<input type="text" class="form-control" name="discount" value="" placeholder="Discount*" required>
											</div>
										</div>
								      </div>  
                                            
                                      <div class="col-md-3">
										<div class="form-group">
											<div class="col-md-12">
												<input type="text" class="form-control" name="shipping_cost" value="" placeholder="shipping cost*" required>
											</div>
										</div>
								     </div>    
                                            
                                      <div class="col-md-3" style="display:none;">
										<div class="form-group">
											<div class="col-md-12">
												<input type="text" class="form-control" name="item_details" value="" >
											</div>
										</div>
								      </div>           
                                
                                            
                                      <div class="col-md-6">
											 <div class="form-group">
												 <div class="col-md-12">
                                                     <textarea class="form-control" name="discription" placeholder="Discription" style="height:37px;"><?php if(isset($product_selected[0])){ echo $product_selected[0]->discription; } ?></textarea>
												</div>
											</div>
						             </div>         
                                </div>
                                  
									<div class="col-md-2" style="margin-left:15px;">
											<div class="form-group">
												<div class="col-md-12">
													<input type="submit" class="btn btn-primary" name="submit" value="submit" style=" width:100%;">
												</div>
											</div>
						      </div>
									<div class="col-md-2">
											<div class="form-group">
												<div class="col-md-12">
												<a href="<?php echo base_url(); ?>product/add_product">	<button type="button" class="btn-transparent btn-red"  style=" width:100%;">Cancel</button></a>
												</div>
											</div>
						      </div>
									</form>
                             
                             
                             
						</div>
                        
                          <div class="seacrch_product" style="padding-left: 30px; padding-right: 30px; margin-bottom:15px; ">
                            <div class="form-group" style=" position:relative; width:100%;">
                                               <span class="search_input_i"><i class="fa fa-search"></i></span>
                                              <input type="text" class="form-control" value="" id="my_drop_down_input" placeholder="Barcode | Product Name" style="padding-left:30px;">
                                
                                
                                               <ul class="my_drop_down" style="list-style:none; padding:0px;">
                                                   <li class="active">Select Product</li>
                                                 
                                               </ul>
											
													<!--<select data-plugin-selectTwo class="select-control populate" id="search_item" style="background-color: #3c3f52; width: 100%;" >
                                                       
													</select> -->
											</div>
                           
                            </div> 
                        
                          <div class="panel-body " style="padding-top:0px; padding-left: 30px; padding-right: 30px;">
								   <table class="table mb-none" id="table" data-toggle="table" data-pagination="true" style="border-bottom: 1px solid #424351;">
									 <thead>
									   	<tr>
											 <th>Sr no</th>
											 <th>Product Name</th>
								             <th>Qty</th>
								             <th>Unit Price</th>
                                             <th>Discount</th>
											 <th>Tax</th>
											 <th>Subtotal</th>
											 <th>Action</th>
										</tr>
									</thead>
									<tbody class="item_table">
										 <!--<tr>
                                             <td>1</td>
                                              <td>Nudels</td>
                                              <td><input type="number" class="form-control" value="" name="p_qty"  style="width: 150px;" data-price="100"></td>
                                              <td>320</td>
                                              <td>00</td>
                                              <td>10 </td>
                                             <td class="subtotal">330 </td>
                                             <td><button type="button" name="del" class="btn"><i class="fa fa-home"></i></button></td>
                                             
                                        </tr> -->
									</tbody>
                                       
                                       <tfoot>
                                            <tr>
                                                <td>Total</td>
                                                <td></td>
                                                <td class="footer_qty"></td>
                                                <td></td>
                                                <td></td>
                                                <td class="footer_tax"></td>
                                                <td class="footer_subtotal"></td>
                                                <td></td>
                                           </tr>
                                       </tfoot>
                                       
								</table>
							</div>
          </section>
				</div>
						<div class="col-md-12" style="padding:0px; padding-right:15px; margin-bottom:15px;"> 
						<!--<section class="section_card" id="table_section">
								 <header class="panel-heading" style="padding:0px 15px;">
								     	<div class="heading_box" style=" border-bottom: none; padding: 6px 2px; height:36px; background-color:#27293d;">
									        <h2 class="panel-title" style="color:#dbd6d6; font-size:16px; line-height:10px; text-transform:uppercase;">
														<i class="ion-android-radio-button-on" style="margin-right:10px;"></i>
														Product List <i class="ion-chevron-right" style="padding:0px 10px; color:#0088cc;"></i> <?php  if(isset($product_list[0]->product_sub_category_name)){ echo $product_list[0]->product_sub_category_name;  } ?>
														<i class="ion-chevron-right" style="padding:0px 10px; color:#0088cc;"></i>
														<?php  if(isset($product_list[0]->product_category_name)){ echo $product_list[0]->product_category_name;  } ?>
													</h2>
									    </div>
								</header> 
							  <div class="panel-body " style="padding-top:0px;">
								   <table class="table mb-none" id="table" data-toggle="table" data-pagination="true" style="border-bottom: 1px solid #424351;">
									 <thead>
									   	<tr>
											 <th>Sr no</th>
										   
											 <th>Product Name</th>

												 <th>Unit</th>
												 <th>Price</th>
                                             <th>GST</th>
											   <th class="hidden-phone">Status</th>
											   <th>Edit</th>
											   <th>Action</th>
										</tr>
									</thead>
									<tbody class="item_table">
										 
                                         
									</tbody>
								</table>
							</div>
						</section> -->
					</div>
					
		<!-- main section -->
        </section>
	 <!-- inner wrapper -->
		</div>
		<?php $this->load->view('common/sidebar_right'); ?>
		<!-- Body section -->
		</section>
		<!-- Delete confimation model -->
		          <div id="del_alert_action" class="modal modal-edu-general FullColor-popup-DangerModal fade" role="dialog" data-backdrop="static" data-keyboard="false" style="width:460px; margin:auto;">
										 <div class="modal-dialog" style="width:90%;">
												 <div class="modal-content">
														 <div class="modal-close-area modal-close-df">
																 <a class="close" data-dismiss="modal" href="#"><i class="fa fa-close"></i></a>
														 </div>
														 <div class="modal-body" style="padding: 30px 30px; background-color:#363956; text-align:center; color:#ffffff;">
																 <span class="ion-ios-flame-outline" style="font-size:50px; color:#ff4747;"></span>
																 <h2 style="margin-top:6px;">Are You Sure!</h2>
																 <p class="fail_model_p">Do you want to delete this account?</p>
														 </div>
														 <div class="modal-footer danger-md" style=" background-color:#363956; border-top:none;">
																 <button class="btn-transparent btn-red" type="button" data-dismiss="modal" style="width:80px;">No</button>
																 <button data-del_id="" id="del_bt" class="btn-transparent btn-green" type="button"  style="width:80px; ">Yes</button>
					                                     </div>
												 </div>
										 </div>
								 </div>

<?php $this->load->view('common/footer_script'); ?>
<script src="<?php echo base_url(); ?>/catalogs/assets/javascripts/image-compressor.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/Lobibox.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/notification-active.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/vendor/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    
   // calculate item table footer total
    
    function cal_item_table_total(){
        
        var total_qty = 0;
        var total_subtotal = 0;
        var total_tax = 0;
        // qty
        $('input[name=p_qty]').each(function(){
            var qty =  $(this).val();
           
            total_qty += Math.abs(qty);
        });
        
        // subtotal
        
        $('.subtotal').each(function(){
            var subtotal = $(this).html();
            total_subtotal += Math.abs(subtotal);
        });
        
        // tax
        $('.tax').each(function(){
           var tax =  $(this).html();
           total_tax += Math.abs(tax); 
        });
        
        $('.footer_qty').html(total_qty);
        $('.footer_subtotal').html(total_subtotal);
        $('.footer_tax').html(total_tax);
        
        // product details data
        var product_details_arr = [];
        
        
        $('.item_tr').each(function(){
            
            var item_id = $(this).data('item_id');
            var item_qty = $(this).find('input[name=p_qty]').val();
            var item_price =   $(this).find('input[name=p_qty]').data("price");
            var tax  = $(this).find('.tax').val();
            var subtotal = $(this).find(".subtotal").html();
            var discount = $(this).find(".discount").html();
             product_details_arr.push({item_id:item_id,item_qty:item_qty,item_price:item_price,discount:discount,tax:tax,subtotal:subtotal});
            
        });
        
       //console.log(product_details_arr);
        
        var str_product_details_arr = JSON.stringify(product_details_arr);
        
        $('input[name=item_details]').val(str_product_details_arr);
     
    }
    cal_item_table_total();
    
    
       $(document).on('keydown','#my_drop_down_input',function(){
           
           var key  = event.which;
           
           if(key === 38){
                var index = $('.my_drop_down li.active').index();
                var next_index = Math.abs(index - 1);
                
                $('.my_drop_down li').eq(next_index).addClass('active');
                $('.my_drop_down li').eq(index).removeClass('active');
           }
           
           
           if(key === 40){
               
                var index = $('.my_drop_down li.active').index();
                var next_index = Math.abs(index + 1);
                
                $('.my_drop_down li').eq(next_index).addClass('active');
                $('.my_drop_down li').eq(index).removeClass('active');
              
               
           }
           
             if(key === 13){
                 $('.my_drop_down li.active').click();
                 
             }
       });
     // set scroll position
		 $(document).on('keyup','#my_drop_down_input',function(){
             var key  = event.which;
             if(key !== 38 && key !== 40 && key !== 13){
             
             var val = $(this).val();
               
             
             $.ajax({
				 type: 'POST',
				 url: '<?php echo base_url(); ?>inventory/search_product',
				 data:{val:val},
				 success:function(html){
				     var my_data = JSON.parse(html).list;
                   
                    // console.log(my_data);
                       $('.my_drop_down').html('').show();
                     for(var i = 0; i < my_data.length; i++ ){
                         
                         
                         $('.my_drop_down').append('<li value="'+my_data[i].product_id+'">'+my_data[i].product_name+'</li>');
                         //$('.my_drop_down li').eq(0).addClass('active');
                     }

				 }
			});
             }
             
           
         });
    
       $(document).on('click','.my_drop_down li',function(){
            
           var p_id = $(this).val();
           $('.my_drop_down').hide().html('');
            $('#my_drop_down_input').val('');
           //alert(p_id);
             $.ajax({
				 type: 'POST',
				 url: '<?php echo base_url(); ?>inventory/search_product_by_id',
				 data:{p_id:p_id},
				 success:function(html){
				     var my_data = JSON.parse(html).list;
                     
                     // convert gst in rupee
                     var gst = (Math.abs(my_data[0].sgst) +Math.abs(my_data[0].cgst));
                     var gst_in_rupee = Math.abs(gst) * Math.abs(my_data[0].product_unit_price) / 100;
                     
                     
                      $('.item_table').find('tr[class=no-records-found]').remove();
                      $('.item_table').append('<tr class="item_tr" data-item_id="'+my_data[0].product_id+'"  ><td>1</td><td>'+my_data[0].product_name+'</td><td><input type="number" class="form-control" value="1" name="p_qty"  style="width: 150px;" data-price="'+my_data[0].product_unit_price+'"></td> <td class="discount">'+my_data[0].product_unit_price+'</td> <td>0</td> <td class="tax">'+ gst_in_rupee +'</td> <td class="subtotal">'+my_data[0].product_unit_price+' </td> <td><button type="button" name="del" class="btn" style="color:#ff4748;">X</button></td></tr>');
                     
                       cal_item_table_total();

				 }
			});
              
       });
    
  
    
    
    
    
    // ==========================
    
        
      $(document).on('change','input[name=p_qty]',function(){
          
          var qty = $(this).val();
          var price = $(this).data("price");
          var cal_price = Math.abs(qty) * Math.abs(price);
          $(this).parent().parent().find('.subtotal').html(cal_price);            
          cal_item_table_total();
      });
    
      $(document).on('keyup','input[name=p_qty]',function(){
          var qty = $(this).val();
          var price = $(this).data("price");
          var cal_price = Math.abs(qty) * Math.abs(price);
          $(this).parent().parent().find('.subtotal').html(cal_price);  
        
         cal_item_table_total();
          
      });
    
     // remover item tr
    
    $(document).on('click','button[name=del]',function(){
         $(this).parent().parent().remove();
         cal_item_table_total();
    });
    
});
</script>
</body>
</html>
