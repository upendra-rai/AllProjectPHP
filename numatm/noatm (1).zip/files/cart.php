<html>
<head>
<title>add to cart</title>
   
  <?php include('header_link.php');?>
</head>
<body>
     <!--head_bar section -->
     <!--head_bar section -->
     <!--head_bar section -->
     <!--head_bar section -->
  <?php include('menu_bar.php'); ?>
     <!--menu_bar section -->
     <!--menu_bar section -->
     <!--menu_bar section -->
     <!--menu_bar section -->

         <!--billing section -->
         <!--billing section -->
         <!--billing section -->
         <!--billing section -->
  <section class="billing">
      <div class="container">
          <div class="row" style="margin-top: 20px">
    <div class="col-md-8" style=" margin-bottom: 10px; ">
         <div class="box" >     
               <div class="heading" style="text-align: left; padding: 6px;">
            <h3 style="">your favourites</h3>
           
        </div>
        <table class="table">
            <thead>
                <tr>
                    <td>Numbers</td>
                     <td>Price</td>
                </tr>
            
            </thead>
           <tbody>
                <tr>
                    <td>
                        <b>99-88-99-88-99</b>
                        <p class="total">Total 23 &nbsp;|&nbsp; Sum 05 &nbsp; <span class="r2p">R2P</span>&nbsp;&nbsp; | &nbsp;&nbsp; <span style="color:#a6a6a6;"> <i class="fa fa-eye"></i>&nbsp;&nbsp; 321 &nbsp;&nbsp;<i class="fa fa-heart"></i> 44 </span></p>
                    </td>
                    
                     <td>
                         <b>Rs. 37,500</b>
                    </td>
               
               </tr>
               <tr>
                    <td>
                          
                        <b>99-88-99-88-99</b>
                          <p class="total">
                              Total 23 &nbsp;| &nbsp;Sum 05&nbsp;  <span class="r2p">R2P</span>&nbsp;&nbsp; | &nbsp;&nbsp; <span style="color:#a6a6a6;"> <i class="fa fa-eye"></i>&nbsp;&nbsp; 321 &nbsp;&nbsp;<i class="fa fa-heart"></i> 44</span></p>
                    </td>
                    
                     <td>
                         <b>Rs. 37,500</b>
                    </td>
               
               </tr>
            </tbody>
        
        
        
        
        </table>
        
        </div>
              </div>
          <div class="col-md-4"style="padding-left: 0px;">
              <div class="box" style="padding: 10px;">
               
        <table class="table">
            <thead>
                <tr>
                    <td>Summary</td>
                     <td></td>
                </tr>
            
            </thead>
           <tbody>
                <tr>
                    <td style="font-size: 14px; border-bottom: 1px solid transparent;">
                        Total (2 items)
                        
                    </td>
                    
                     <td  style="font-size: 14px; border-bottom: 1px solid transparent; ">
                          Rs. 75,000
                    </td>
               
               </tr>
                <tr>
                    <td  style="font-size: 14px; ">
                       Tax
                        
                    </td>
                    
                     <td  style="font-size: 14px;">
                          0
                    </td>
               
               </tr>
              
            </tbody>
        
        <tfoot>
            <tr>
                    <td  style="font-size: 14px;">
                      Subtotal (2 items)
                        
                    </td>
                    
                     <td  style="font-size: 14px;">
                         Rs. 75,000
                    </td>
               
               </tr>
              
            </tfoot>
        
        
        </table>
        
              </div>
              </div>
              </div>
          </div>
       
        
    
     
    
        </section>
    <!--contact section -->
     <!--contact section -->
     <!--contact section -->
     <!--contact section -->
    <section class="contact">
        <div class="container">
             <div class="box">
            <div class="row">
            
             <div class="heading" style="">
            <h3>Please fill checkout the details</h3>
        </div>
            </div>
            <div class="row">
        <div class="col-md-12">
           
            
        
            <div class="col-md-12" >
      

        <form >
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="NAME" placeholder="NAME"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input class="form-control" type="text"  name="NAME" placeholder="Mobile Number"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="NAME" placeholder="Email"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="NAME" placeholder="City"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="NAME" placeholder="State"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="NAME" placeholder="Pincode"><br>  
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <textarea class="form-control" name="" placeholder="Address" style="height: 100px; "></textarea>
                   
                </div>
            </div>
            <div class="col-md-12" style="text-align: center;">
                <div class="form-group">
                       <button type="button" class="my_btn" style="font-size: 14px;">Pay now Rs. 75,000</button>
                </div>
            </div>
        
        
     
        </form>
                <p style="color:#999999; padding-top: 15px; margin-top: 65px; margin-bottom: 35px;">* By clicking on the pay now button means that you are agreeing to our terms and conditions</p>
            </div>
                </div>
            </div>
                </div>
            </div>
    </section>
    <!--yourfav section -->
     <!--yourfav section -->
     <!--yourfav section -->
     <!--yourfav section -->
    <section class="yourfav">
        <div class="container"  >
            <div class="box">
          <div class="row">
        <div class="heading">
            <h3 style="">your favourites</h3>
           
        </div>
        </div>
         <div class="row" >
                 <div class="swiper-container1" style="padding-left: 50px; padding-right: 50px; border: 1px solid red; height: 250px; ">
    <div class="swiper-wrapper" style="overflow: hidden;">
      <div class="swiper-slide"> <div class="simcard">
                <p class="number">99-88-99-88-99<span style=" float: right; "><i class="ion-android-favorite-outline" style="color: white;"></i></span>
                </p>
                <p class="pricing"><span class="selling_price">INR 37,500</span>&nbsp; <span class="mrp_price"> inr44,000 </span> &nbsp; <span class="discount">%15 off</span>
                </p>
                <p class="total">Total 23  &nbsp; &nbsp; sum05 &nbsp;&nbsp;<span>R2P</span>
                </p>
                <div class="like_view" >
                <div class="box1" ><i class="ion-ios-eye-outline" style="  color:#afb7af"></i></div>
                    <div class="box2" >&nbsp;321</div>
                    <div class="box3"><i class="ion-android-favorite-outline" style=" color:#afb7af"></i></div>
                    <div class="box4" >&nbsp;321</div>
                </div>
                <div class="action">
                    <div class="col-md-6" style="padding-left:0px; text-align:left;">
                     <a herf="">add to cart</a>
                    
                    </div>
                   <div class="col-md-6">
                    <button type="button" class="my_btn">Buy now</button>
                    </div>
                </div>
            </div></div>
      <div class="swiper-slide"><div class="simcard">
                <p class="number">99-88-99-88-99<span style=" float: right; "><i class="ion-android-favorite-outline" style="color: white;"></i></span>
                </p>
                <p class="pricing"><span class="selling_price">INR 37,500</span>&nbsp; <span class="mrp_price"> inr44,000 </span> &nbsp; <span class="discount">%15 off</span>
                </p>
                <p class="total">Total 23  &nbsp; &nbsp; sum05 &nbsp;&nbsp;<span>R2P</span>
                </p>
                <div class="like_view" >
                <div class="box1" ><i class="ion-ios-eye-outline" style="  color:#afb7af"></i></div>
                    <div class="box2" >&nbsp;321</div>
                    <div class="box3"><i class="ion-android-favorite-outline" style=" color:#afb7af"></i></div>
                    <div class="box4" >&nbsp;321</div>
                </div>
                <div class="action">
                    <div class="col-md-6" style="padding-left:0px; text-align:left;">
                     <a herf="">add to cart</a>
                    
                    </div>
                   <div class="col-md-6">
                    <button type="button" class="my_btn">Buy now</button>
                    </div>
                </div>
            </div></div>
      <div class="swiper-slide"><div class="simcard">
                <p class="number">99-88-99-88-99<span style=" float: right; "><i class="ion-android-favorite-outline" style="color: white;"></i></span>
                </p>
                <p class="pricing"><span class="selling_price">INR 37,500</span>&nbsp; <span class="mrp_price"> inr44,000 </span> &nbsp; <span class="discount">%15 off</span>
                </p>
                <p class="total">Total 23  &nbsp; &nbsp; sum05 &nbsp;&nbsp;<span>R2P</span>
                </p>
                <div class="like_view" >
                <div class="box1" ><i class="ion-ios-eye-outline" style="  color:#afb7af"></i></div>
                    <div class="box2" >&nbsp;321</div>
                    <div class="box3"><i class="ion-android-favorite-outline" style=" color:#afb7af"></i></div>
                    <div class="box4" >&nbsp;321</div>
                </div>
                <div class="action">
                    <div class="col-md-6" style="padding-left:0px; text-align:left;">
                     <a herf="">add to cart</a>
                    
                    </div>
                   <div class="col-md-6">
                    <button type="button" class="my_btn">Buy now</button>
                    </div>
                </div>
            </div></div>
      <div class="swiper-slide"><div class="simcard">
                <p class="number">99-88-99-88-99<span style=" float: right; "><i class="ion-android-favorite-outline" style="color: white;"></i></span>
                </p>
                <p class="pricing"><span class="selling_price">INR 37,500</span>&nbsp; <span class="mrp_price"> inr44,000 </span> &nbsp; <span class="discount">%15 off</span>
                </p>
                <p class="total">Total 23  &nbsp; &nbsp; sum05 &nbsp;&nbsp;<span>R2P</span>
                </p>
                <div class="like_view" >
                <div class="box1" ><i class="ion-ios-eye-outline" style="  color:#afb7af"></i></div>
                    <div class="box2" >&nbsp;321</div>
                    <div class="box3"><i class="ion-android-favorite-outline" style=" color:#afb7af"></i></div>
                    <div class="box4" >&nbsp;321</div>
                </div>
                <div class="action">
                    <div class="col-md-6" style="padding-left:0px; text-align:left;">
                     <a herf="">add to cart</a>
                    
                    </div>
                   <div class="col-md-6">
                    <button type="button" class="my_btn">Buy now</button>
                    </div>
                </div>
            </div></div>
    
    </div>
   
  </div>
          
    
    
    
            </div>
    </div>
        </div>
    </section>
     <!--footer section -->
     <!--footer section -->
     <!--footer section -->
     <!--footer section -->
     <?php include('footer.php');?>
     <?php include('footer_script.php');?>
     <script>
    var swiper = new Swiper('.swiper-container');
         var swiper = new Swiper('.swiper-container1', {
      slidesPerView: 3,
      slidesPerColumn: 1,
      spaceBetween: 30,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
  </script>
    
</body>
</html>