<html>
<head>
    <title>enquiry</title>
  <?php include('header_link.php');?>
    </head>
    <body>
        <!--head_bar section -->
     <!--head_bar section -->
     <!--head_bar section -->
     <!--head_bar section -->
        <?php $active='enquiry';
    ?>  
  <?php include('menu_bar.php'); ?>
   
        <!--enquiry section -->
     <!--footer section -->
     <!--footer section -->
     <!--footer section -->
        
  <section class="enquiry">
        <div class="container">

        <div class="col-md-6">
                 </div>
            
       <div class="col-md-6 enquiry_form">
             
        <div class="heading">
            <h3>Enquiry Now</h3>
        </div>
        <form action="" method="post">
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="required_number" placeholder="Required Number" required><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <input class="form-control" type="text"  name="budget" placeholder="Enter Budget"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="name" placeholder="Your Name"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="email" placeholder="Enter your email address"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="number" placeholder="Enter your Mobile Number"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="address" placeholder="Enter your Address 1"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="city" placeholder="Enter your City"><br>  
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <input class="form-control" type="text"  name="post_code" placeholder="Enter your Post Code"><br>  
                </div>
            </div>
            
            <div class="col-md-12" style="text-align: center;">
                <div class="form-group">
                       <input type="submit" name="submit" value="send" class="my_btn" style="font-size: 14px; width: 150px;">
                </div>
            </div>
        
        
     
        </form> 
            </div>
                </div>
     
        </section>
        
  
    <!--footer section -->
     <!--footer section -->
     <!--footer section -->
     <!--footer section -->
  <?php include('footer.php');?>
     <?php include('footer_script.php');?>

    </body>
  
</html>
