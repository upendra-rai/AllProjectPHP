<html>
<head>
<?php include('header_link.php'); ?>
    </head>
<body>
    <?php
    $active ='home';
    ?>
     <!--head_bar section -->
     <!--head_bar section -->
     <!--head_bar section -->
     <!--head_bar section -->

    <!--menu_bar section -->
     <!--menu_bar section -->
     <!--menu_bar section -->
     <!--menu_bar section -->
    <?php include('menu_bar.php'); ?>
    
    <section class="numberology">
        <div class="container">
            <div class="row">
            <div class="heading">
            <h3>Know your lucky number</h3>
        </div>
            </div>
            <div class="row">
                
    <div class="col-md-5">
        <img src="image/numberology.PNG" alt="">
    </div>
     <div class="col-md-7" style="padding-top:50px;">
         <div class="col-md-4">
         <div class="form-group">
         <input type="text" value="" name="" class="form-control" placeholder="Your Name">
             </div>
             </div>
         <div class="col-md-4">
         <div class="form-group">
         <input type="date" value="" name="" class="form-control" placeholder="Enter DOB">
             </div>
         </div>
         <div>
             <div class="col-md-4">
         <button type="button" class="my_btn" style="height:36px;">calculate now</button>
             </div>
         </div>
                
                <div class="col-md-12">
                <p class="para1"><b>Here’s some number recommended for you</b></p>
                    <p class="para2">99-88-99-88-99, 885-445-9988, 70000-66544,<br>88888-56655, 6222-2222-22</p>
                    <p class="para3">Still looking for your lucky number?</p>
                    <button type="button" class="my_btn">connect with experts</button>
                </div>
                </div>
                
    </div>
    </div>
    
    
    </section>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
<!--footer section -->
     <!--footer section -->
     <!--footer section -->
     <!--footer section -->
    <?php include('footer.php');?>
     <?php include('footer_script.php');?>