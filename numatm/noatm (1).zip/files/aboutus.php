<html>
<head>
<title> about_us page</title>
     <?php include('header_link.php');?>
    </head>
<body>
   <?php $active='about';
    ?>       <!--head_bar section -->
          <!--head_bar section -->
          <!--head_bar section -->
          <!--head_bar section -->
  <?php include('menu_bar.php'); ?>
         <!--main_img section -->
          <!--main_img section -->
          <!--main_img section -->
          <!--main_img section -->
    
    <section class="sim_img">
    <div>
        <img src="image/about.png" style="width: 100%";>
        
        </div>
    
    
    
    </section>
    
    
          <!--content section -->
          <!--content section -->
          <!--content section -->
          <!--content section -->
    
    
    <section class="content">
        
            <div class="heading">
            <h3>About Us</h3>
        </div>
            <div class="paragraph">
        <p>Vip Numbercity was established in 2012 and still running with full efficiency and dedication. It is a one-stop destination for all
mobile number solution. We feel delighted to say that in these 7 years we have provided our services to more than 1 lakh
customers across the country and still counting. All of our VIP Mobile Numbers are roaming free and portability enabled in
any state of India.<br>
Our long term relationship with many VIPs who have happily taken fancy and extraordinary looking numbers from us is the
symbol of our success and achievements.<br>
VipNumbercity mobile numbers are the perfect choice for increasing business status and potential. All the big successful
companies out there are using fancy contact numbers which are easy to remember. Our company is run by young, talented
and enthusiastic professionals and that is what makes us more dynamic and different from others. We assure 100% consumer
satisfaction and provide the best service for our valuable customers.</p>
        
        
        </div>
    
    
    
        
    </section>
          <!--footer section -->
          <!--footer section -->
          <!--footer section -->
          <!--footer section -->
    
     <?php include('footer.php');?>
     <?php include('footer_script.php');?>
</body>
</html>