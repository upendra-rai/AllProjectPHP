<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class cart extends CI_Controller {

	function __construct(){

		parent::__construct();

	}
    
    public function index(){
        echo  'ssss';
    }
    
     public function cart(){
        $this->load->view('cart');
    }
	
}
