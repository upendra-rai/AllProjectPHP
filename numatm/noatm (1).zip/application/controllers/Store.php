<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class store extends CI_Controller {

	function __construct(){

		parent::__construct();
         $this->load->model('model_home');

	}
    
    public function index(){
        echo  'ssss';
    }
    
     public function store(){
        
         
         $data['category_list']  = $this->model_home->selectcategory_list();
         $data['product_list']  = $this->model_home->selectproduct();
         //print_r ($data);
         $this->load->view('store', $data);
       
    }
	
}
