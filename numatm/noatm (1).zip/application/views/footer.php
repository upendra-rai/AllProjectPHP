 <section class="footer">
        <div class="container">
            
            <div class="row">
                <div class="col-md-8">
                    <div class="information">
                         <h4>About Company’s</h4>
                        <p><a href="terms.php">Terms & Conditions</a> |<a href="refund.php">Refund & Cancellation Policy</a>  | <a href="privacy.php">Privacy Policy</a></p>
                    </div>
                </div>
                <div class="col-md-4" style="text-align: right;">
                    <p>Experience number atm on mobile</p>
                    <img src="<?php echo base_url();  ?>/files/image/playstore.png" alt="">
    
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="information">
                       <h4>Categories</h4>
                        <p>00000 Numbers | 000000 Numbers | 00X00 & 00XY00 |000000 Numbers |00X00 & 00XY00 | 13 Special| 13 Special | 3 Digit NUmbers | 786 Special | 3 Digit NUmbers|00000 Numbers | 000000 Numbers | 00X00 & 00XY00 </p>
                    </div>
                </div>
               
            </div>
            
            <div class="row">
                <div class="col-md-9">
                    <div class="information">
                       <p><i class="fa fa-phone-alt"></i> &nbsp;+919220456-923456 &nbsp;<i class="ion-email"></i> &nbsp; info@numbersatm.com &nbsp;<i class="ion-android-time"></i> &nbsp; Monday to Saturday - 10:00 AM to 10:00 PM</p>
                    </div>
                </div>
                <div class="col-md-3">
                   <div claas="icon">
            <img src="<?php echo base_url();  ?>/files/image/Group%20181.png" alt="">
            <img src="<?php echo base_url();  ?>/files/image/Group%20182.png" alt="">
            <img src="<?php echo base_url();  ?>/files/image/Group%20183.png" alt="">
            <img src="<?php echo base_url();  ?>/files/image/Group%20185.png" alt="">
            <img src="<?php echo base_url();  ?>/files/image/Group%20186.png" alt="">
            <img src="<?php echo base_url();  ?>/files/image/Group%20188.png" alt="">
            </div>
    
                </div>
            </div>
   
        </div>
   
        </section>