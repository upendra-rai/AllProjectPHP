<html>
<head>
   <title>signup page</title> 
     <?php include('header_link.php');?>
    
    </head>
<body>
       <!--head_bar section -->
     <!--head_bar section -->
    <!--head_bar section -->
     <!--head_bar section -->
  <?php include('menu_bar.php'); ?>
    
    <section class="signup" style="background-color: white;">
       <div class="container" style="width:100%; padding:0px;">
           <div class="row">
        <div class="col-md-6">
        <div class="loginimg">
        
            </div>
        </div>
        <div class="col-md-6" style="margin-top: 50px; text-align: center; padding-left: 100px; padding-right: 100px;" >
            <form>
                <div class="form-group">
                 <h1 class="signup_head"> Sign In </h1>
                </div>
                
                <div class="form-group">
                   <input class="form-control" type="text"  name="NAME" placeholder="username">  
                </div>
                <div class="form-group">
                    <input class="form-control" type="text"  name="NAME" placeholder="password"> <a herf="" style=" width:100%; color:red; text-align: right; float:right;">forgot password</a>  
                </div>
                
                <button type="button" class="my_btn" style="text-align: center; margin-top: 30px; margin-bottom: 15px;">sign in</button>
                <p class="signup_para" style="padding:8px 40px; font-size: 14px;">not registered? &nbsp; <a href="" style="color: red; ">sign up here</a></p>
                
                
                
                
                    
            </form>
            </div>
           </div>
       
        </div>
        
            </section>

    <!--footer section -->
     <!--footer section -->
     <!--footer section -->
     <!--footer section -->
    <?php include('footer.php');?>
     <?php include('footer_script.php');?>
    </body>

</html>