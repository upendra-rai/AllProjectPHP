<html>
<head>
<title> Refund_page</title>
     <?php include('header_link.php');?>
    </head>
<body>
   <?php $active='refund_page';
    ?>       <!--head_bar section -->
          <!--head_bar section -->
          <!--head_bar section -->
          <!--head_bar section -->
  <?php include('menu_bar.php'); ?>
         <!--main_img section -->
          <!--main_img section -->
          <!--main_img section -->
          <!--main_img section -->
    
    
    
          <!--content section -->
          <!--content section -->
          <!--content section -->
          <!--content section -->
    
    <section class="content" style="height:700px;">
        
            <div class="heading">
            <h3><b>NUMBERSATM REFUND POLICY</b></h3>
        </div>
            <div class="paragraph">
                <p style="padding-bottom:15px;"><b>Once the purchase is done, the customer can’t cancel the order. Unfortunately, we can’t offer you refund or exchange if 30 days have gone since your purchase. Certain criteria should be followed to become eligible for the refund. Several numbers are exempted and could not be returned. in following cases we refund in just 30 days:</b></p>
<ul>
    <li>(1) we are unable to offer you the VIP number that you booked using our site. we are unable to offer you the VIP number that you booked using our site. (2) if the number is not delivered to you within 10 days. 3) if number provided gets terminated within three months.
        2) if the number is not delivered to you within 10 days. 3) if number provided gets terminated within three months.</li>
    <li>we require proof of purchase or receipt for completing your return. We request you to not send your number back to the sender.</li>
    <li>situations for granting partial refunds: (if applicable)</li>
    <li>(1) if the customer wants the exchange of numbers. ( in certain situations only) 2) missing numbers in bulk. 3) in some situations of acceptance. 4) problems occurring in our systems or issues after booking process.</li>
    <li>refunds (if applicable)</li>
    <li>After receiving and inspecting your return we will notify you about it through email. Also, we will notify you whether your refund request was approved or rejected.</li>
    <li>if approved, the refund will be processed and the amount will be credited to your original method of payment or your credit card within 10 to 12 working days.</li>
    <li>Missing or late refunds (if applicable)</li>
    <li>if you didn’t receive the refund yet, we suggest you check your bank account again. It may take some time till the refund is officially posted, so you can contact your credit card company and bank. Some processing time is generally taken but if you don’t receive the refund even after following these steps, please contact us at info@numbersatm.com</li>
                </ul>
        
        
        </div>
    
    
    
        
    </section>
          <!--footer section -->
          <!--footer section -->
          <!--footer section -->
          <!--footer section -->
    
     <?php include('footer.php');?>
     <?php include('footer_script.php');?>
</body>
</html>