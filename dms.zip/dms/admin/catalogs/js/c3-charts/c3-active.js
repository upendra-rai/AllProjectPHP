(function ($) {
 "use strict";
  

            c3.generate({
                bindto: '#lineChart',
                data:{
                    columns: [
                        ['data1', 30, 200, 100, 400, 150, 250],
                        ['data2', 50, 20, 10, 40, 15, 25]
                    ],
                    colors:{
                        data1: '#006DF0',
                        data2: '#933EC5'
                    }
                }
            });

            c3.generate({
                bindto: '#slineChart',
                data:{
                    columns: [
                        ['data1', 30, 200, 100, 400, 150, 250],
                        ['data2', 130, 100, 140, 200, 150, 50]
                    ],
                    colors:{
                        data1: '#006DF0',
                        data2: '#933EC5'
                    },
                    type: 'spline'
                }
            });

            c3.generate({
                bindto: '#scatter',
                data:{
                    xs:{
                        data1: 'data1_x',
                        data2: 'data2_x'
                    },
                    columns: [
                        ["data1_x", 3.2, 3.2, 3.1, 2.3, 2.8, 2.8, 3.3, 2.4, 2.9, 2.7, 2.0, 3.0, 2.2, 2.9, 2.9, 3.1, 3.0, 2.7, 2.2, 2.5, 3.2, 2.8, 2.5, 2.8, 2.9, 3.0, 2.8, 3.0, 2.9, 2.6, 2.4, 2.4, 2.7, 2.7, 3.0, 3.4, 3.1, 2.3, 3.0, 2.5, 2.6, 3.0, 2.6, 2.3, 2.7, 3.0, 2.9, 2.9, 2.5, 2.8],
                        ["data2_x", 3.3, 2.7, 3.0, 2.9, 3.0, 3.0, 2.5, 2.9, 2.5, 3.6, 3.2, 2.7, 3.0, 2.5, 2.8, 3.2, 3.0, 3.8, 2.6, 2.2, 3.2, 2.8, 2.8, 2.7, 3.3, 3.2, 2.8, 3.0, 2.8, 3.0, 2.8, 3.8, 2.8, 2.8, 2.6, 3.0, 3.4, 3.1, 3.0, 3.1, 3.1, 3.1, 2.7, 3.2, 3.3, 3.0, 2.5, 3.0, 3.4, 3.0],
                        ["data1", 1.4, 1.5, 1.5, 1.3, 1.5, 1.3, 1.6, 1.0, 1.3, 1.4, 1.0, 1.5, 1.0, 1.4, 1.3, 1.4, 1.5, 1.0, 1.5, 1.1, 1.8, 1.3, 1.5, 1.2, 1.3, 1.4, 1.4, 1.7, 1.5, 1.0, 1.1, 1.0, 1.2, 1.6, 1.5, 1.6, 1.5, 1.3, 1.3, 1.3, 1.2, 1.4, 1.2, 1.0, 1.3, 1.2, 1.3, 1.3, 1.1, 1.3],
                        ["data2", 2.5, 1.9, 2.1, 1.8, 2.2, 2.1, 1.7, 1.8, 1.8, 2.5, 2.0, 1.9, 2.1, 2.0, 2.4, 2.3, 1.8, 2.2, 2.3, 1.5, 2.3, 2.0, 2.0, 1.8, 2.1, 1.8, 1.8, 1.8, 2.1, 1.6, 1.9, 2.0, 2.2, 1.5, 1.4, 2.3, 2.4, 1.8, 1.8, 2.1, 2.4, 2.3, 1.9, 2.3, 2.5, 2.3, 1.9, 2.0, 2.3, 1.8]
                    ],
                    colors:{
                        data1: '#006DF0',
                        data2: '#933EC5'
                    },
                    type: 'scatter'
                }
            });
            var tran_bar= [];
            $('.bar_tran_li').each(function(){
                var tran = $(this).text();
                tran_bar.push(tran);
                
            });  
           var rech_bar= [];
           
            $('.bar_recharge_li').each(function(){
                var rech = $(this).text();
                rech_bar.push(rech);
            });
           
            c3.generate({
				
				
                bindto: '#stocked',
                data:{
                    columns: [
                        ['transaction', tran_bar[0],tran_bar[1],tran_bar[2],tran_bar[3],tran_bar[4],tran_bar[5],tran_bar[6],tran_bar[7],tran_bar[8],tran_bar[9],tran_bar[10],tran_bar[11]],
                        ['recharge', rech_bar[0],rech_bar[1],rech_bar[2],rech_bar[3],rech_bar[4],rech_bar[5],rech_bar[6],rech_bar[7],rech_bar[8],rech_bar[8],rech_bar[10],rech_bar[11]]
                    ],
                    colors:{
                        transaction: '#006DF0',
                        recharge: '#933EC5'
                    },
                    type: 'bar',
                    groups: [
                        ['transaction', 'recharge']
                    ]
                }
				
				
				
            });
            
            c3.generate({
                bindto: '#gauge',
                data:{
                    columns: [
                        ['data', 91.4]
                    ],

                    type: 'gauge'
                },
                color:{
                    pattern: ['#006DF0', '#933EC5']

                }
            });
           
            
            c3.generate({
                bindto: '#pie',
                data:{
                    columns: [
                        ['customers', 100,200],
                        ['today_transaction', 100,250]
                    ],
                    colors:{
                        customers: '#006DF0',
                        today_transaction: '#933EC5'
                    },
                    type : 'pie'
                }
            });



})(jQuery); 